﻿To successfully deploy this model we need to satisfy the following requirements:


1. Tensorflow version 1.13(pip install tensorflow)
2. Tflearn (pip install tflearn)
3. OpenCV (pip install opencv)
4. Numpy 
5. matplotlib.pyplot




You can find the Kaggle data set here:
        https://www.kaggle.com/c/dogs-vs-cats-redux-kernels-edition/data


Capstone Proposal link:
        https://review.udacity.com/#!/reviews/2485065